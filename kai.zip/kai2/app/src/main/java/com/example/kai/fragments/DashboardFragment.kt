package com.example.kai.fragments

import androidx.fragment.app.Fragment
import com.example.kai.R

class DashboardFragment: Fragment(R.layout.dashboard_fragment) {
}