package com.example.kai.fragments

import androidx.fragment.app.Fragment
import com.example.kai.R

class SettingsFragment: Fragment(R.layout.settings_fragment) {
}